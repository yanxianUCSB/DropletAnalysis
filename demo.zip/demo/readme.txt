1> Start Matlab
2> Add dropletAnalysis.m and its folder and subfolders to path
3> Run dropletAnalysis.m
4> Choose /demo as root folder
5> Collect result in /demo
